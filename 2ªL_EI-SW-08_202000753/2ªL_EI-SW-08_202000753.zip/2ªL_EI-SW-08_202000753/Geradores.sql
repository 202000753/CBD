/********************************************
 *	UC: Complementos de Bases de Dados 2022/2023
 *
 *	Projeto 1� Fase - Criar os stored procedures geradores
 *		Nuno Reis (202000753)
 *			Turma: 2�L_EI-SW-08 - sala F155 (12:30h - 16:30h)
 *
 ********************************************/
