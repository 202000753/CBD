/********************************************
*	UC: Complementos de Bases de Dados 2022/2023
*
*	Projeto 2� Fase - Mongo DB
*	Nuno Reis (202000753)
*			Turma: 2�L_EI-SW-08 - sala F155 (14:30h - 16:30h)
*
********************************************/
--Consultas necess�rias para popular a base de dados WWIWeb
select *
from RH.BuyingGroup;

select *
from RH.SysUser;

select *
from RH.Customer;

select *
from Storage.Brand;

select *
from Storage.Product;

select *
from Storage.Promotion;

select *
from Storage.Product_Promotion;

select *
from Sales.Sale;

select *
from Sales.ProductPromotion_Sale;